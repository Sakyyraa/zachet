<?php
$sql = new mysqli('localhost', 'root', '', 'project', '3306');
if ($sql->connect_error) { 
    die("Connection failed: " . $sql->connect_error); 
}

$title = $_POST['title'];
$descriptio = $_POST['descriptio'];
$statu = $_POST['statu'];

$stmt = $sql->prepare("INSERT INTO Projects (title, descriptio, statu) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $title, $descriptio, $statu);

if ($stmt->execute()) {
    echo "Проект успешно добавлен!";
} else {
    echo "Ошибка при добавлении проекта: " . $stmt->error;
}
$stmt->close();
$sql->close();
?>
