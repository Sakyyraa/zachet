<?php 
$connect = mysqli_connect('localhost', 'root', '', 'project');
if (!$connect) {
    die("Ошибка: " . mysqli_connect_error());
}
$id = $_GET['id'];
$id = mysqli_real_escape_string($connect, $id);
$sql = "SELECT * FROM Projects WHERE id = '$id'";
$result = mysqli_query($connect, $sql);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $title = $row['title'];
    $description = $row['descriptio'];
    $status = $row['statu'];
} else {
    echo "Проект не найден.";
    exit;
}
mysqli_close($connect);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Изменение проекта</title>
</head>
<style>
    body {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
    }
    form {
        width: 400px;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        text-align: center;
    }
    label {
        display: block;
        margin-bottom: 5px;
    }
    input[type="text"],
    textarea,
    select {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 3px;
    }
    button[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }
    select {
        padding: 10px;
    }
</style>
<body>
    <h2>Изменение проекта</h2>
    <form action="save_update.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">

        <label for="title">Название:</label>
        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($title); ?>"><br><br>

        <label for="descriptio">Описание:</label>
        <textarea id="descriptio" name="descriptio"><?php echo htmlspecialchars($description); ?></textarea><br><br>

        <label for="statu">Статус:</label>
        <select id="statu" name="statu" required>
            <option value="В процессе" <?php echo ($statu == 'В процессе') ? 'selected' : ''; ?>>В процессе</option>
            <option value="Завершен" <?php echo ($statu == 'Завершен') ? 'selected' : ''; ?>>Завершен</option>
            <option value="Отменен" <?php echo ($statu == 'Отменен') ? 'selected' : ''; ?>>Отменен</option>
        </select><br><br>

        <button type="submit">Сохранить изменения</button>
    </form>
</body>
</html>
