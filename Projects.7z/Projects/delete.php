<?php
$connect = mysqli_connect('localhost', 'root', '', 'project');
if (!$connect) {
    die("Ошибка: " . mysqli_connect_error());
}
$id = $_GET['id'];
$sql = "DELETE FROM Projects WHERE id = '$id'";
if (mysqli_query($connect, $sql)) {
    header('Location: hello.php'); 
    exit; 
} else {
    echo "Ошибка при удалении: " . mysqli_error($connect);
}
mysqli_close($connect);
?>