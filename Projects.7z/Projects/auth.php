<?php  
$username = $_POST['username'];   
$password1 = $_POST['password1'];  
 
$sql = new mysqli('localhost', 'root', '', 'project', '3306');  
 
if ($sql->connect_error) { 
  die("Connection failed: " . $sql->connect_error); 
} 
 
$stmt = $sql->prepare("SELECT * FROM Users WHERE username = ?");  
$stmt->bind_param("s", $username);  
$stmt->execute();  
$result = $stmt->get_result();  
 
if ($result->num_rows > 0) {  
  $data = $result->fetch_assoc();  
  if ($password1 == $data['password1']) {   
      header('Location: hello.php');  
  } else {  
    echo "Введен неверный логин или пароль";  
  }  
} else {  
  echo "Введен неверный логин или пароль";  
}  
 
$stmt->close();  
$sql->close();  
?>