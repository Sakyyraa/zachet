<?php
$sql = new mysqli('localhost', 'root', '', 'project', '3306');  
if ($sql->connect_error) { 
  die("Connection failed: " . $sql->connect_error); 
} 
$result = $sql->query("SELECT * FROM Projects");
$data = $result->fetch_all(MYSQLI_ASSOC);
$statuses = ['В процессе', 'Завершен', 'Отменен'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Проекты</title>
</head>
<body>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Название</th>
                <th>Описание</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($data)): ?>
                <?php foreach ($data as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['descriptio']) ?></td>
                        <td><?= htmlspecialchars($row['statu']) ?></td>
                        <td>
                            <a href="delete.php?id=<?= $row['id'] ?>&table=<?= $table ?>" style="color: red;">Удалить</a> |
                            <a href="updata.php?id=<?= $row['id'] ?>&table=<?= $table ?>">Изменить</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5">Нет данных для отображения.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <form action="add.php" method="post" class="mt-4">
        <h5>Добавление проекта</h5>
        <p>Название</p>
        <input type="text" name="title" required>
        <p>Описание</p>
        <textarea name="descriptio" required></textarea>
        <p>Статус</p>
        <select name="statu" required>
            <?php foreach ($statuses as $status): ?>
                <option value="<?= htmlspecialchars($status) ?>"><?= htmlspecialchars($status) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Добавить</button>
    </form>
</body>
</html>
