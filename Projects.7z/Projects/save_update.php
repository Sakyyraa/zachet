<?php
$connect = mysqli_connect('localhost', 'root', '', 'project');
if (!$connect) {
    die("Ошибка: " . mysqli_connect_error());
}
$id = $_POST['id'];
$title = $_POST['title'];
$descriptio = $_POST['descriptio'];
$statu = $_POST['statu'];

$id = mysqli_real_escape_string($connect, $id);
$title = mysqli_real_escape_string($connect, $title);
$descriptio = mysqli_real_escape_string($connect, $descriptio);
$statu = mysqli_real_escape_string($connect, $statu);

$sql = "UPDATE Projects SET title = '$title', descriptio = '$descriptio', statu = '$statu' WHERE id = '$id'";
if (mysqli_query($connect, $sql)) {
    header('Location: hello.php'); 
    exit;
} else {
    echo "Ошибка при обновлении: " . mysqli_error($connect);
}
mysqli_close($connect);
?>
